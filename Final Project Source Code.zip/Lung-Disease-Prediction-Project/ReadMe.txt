cls- clear screen
python model.py- to train the model
python app.py- to run the web app 
ctrl+c- to stop the web app

web app url- http://127.0.0.1:5000
