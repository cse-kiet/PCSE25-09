import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
import pickle

# Data generation (same as above)
np.random.seed(42)
ethnicities = ['Asian', 'Hispanic', 'African-American', 'Caucasian']

n_samples = 1500
data = {
    'Ethnicity': np.random.choice(ethnicities, n_samples),
    'AQI': np.random.randint(50, 300, n_samples),
    'Smokers_Percentage': np.random.randint(5, 50, n_samples),
    'Lung_Disease': np.zeros(n_samples)
}

df = pd.DataFrame(data)

high_risk_samples = pd.DataFrame({
    'Ethnicity': np.random.choice(ethnicities, 500),
    'AQI': np.random.randint(200, 300, 500),
    'Smokers_Percentage': np.random.randint(30, 50, 500),
    'Lung_Disease': np.ones(500)
})

df = pd.concat([df, high_risk_samples], ignore_index=True)

encoder = LabelEncoder()
df['Ethnicity'] = encoder.fit_transform(df['Ethnicity'])

X = df[['Ethnicity', 'AQI', 'Smokers_Percentage']]
y = df['Lung_Disease']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train Random Forest Classifier
rf_model = RandomForestClassifier(class_weight='balanced', random_state=42)
rf_model.fit(X_train, y_train)

with open('rf_model.pkl', 'wb') as file:
    pickle.dump(rf_model, file)

print("Random Forest model trained and saved as rf_model.pkl")
